import numpy as np
import matplotlib.pyplot as plt

from library import num_of_terms

